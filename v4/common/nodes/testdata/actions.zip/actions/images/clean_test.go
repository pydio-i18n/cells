package images

import (
	"github.com/pydio/services/common/proto/jobs"
	. "github.com/smartystreets/goconvey/convey"
	"testing"
)

func TestCleanThumbsTask_GetName(t *testing.T) {
	Convey("Test GetName", t, func() {
		metaAction := &CleanThumbsTask{}
		So(metaAction.GetName(), ShouldEqual, cleanThumbTaskName)
	})
}

func TestCleanThumbsTask_Init(t *testing.T) {

	Convey("", t, func() {

		action := &CleanThumbsTask{}
		job := &jobs.Job{}
		e := action.Init(job, nil, &jobs.Action{})
		So(e, ShouldBeNil)

	})
}
