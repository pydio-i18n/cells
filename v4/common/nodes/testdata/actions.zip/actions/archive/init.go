package archive

import "github.com/pydio/services/scheduler/actions"

func init(){

	manager := actions.GetActionsManager()

	manager.Register(compressActionName, func() actions.ConcreteAction {
		return &CompressAction{}
	})

}